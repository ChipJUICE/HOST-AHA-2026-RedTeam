// =============================================================================
// Testbench: Trojan 2 - Return Address Hijack
// Target:    cv32e40p_register_file_ff.sv
// Trigger:   Write 32'hFEEDFACE to register x28 (t3)
// Payload:   All subsequent reads of x1 (ra) return 32'hDEAD0000
//            → any RET (JALR x0, x1, 0) jumps to attacker-controlled address
// =============================================================================

`timescale 1ns/1ps

module tb_trojan2_ra_hijack;

  // -------------------------------------------------------------------------
  // DUT parameters & signals
  // -------------------------------------------------------------------------
  localparam ADDR_WIDTH = 5;
  localparam DATA_WIDTH = 32;

  logic                    clk, rst_n;
  logic                    scan_cg_en_i;
  logic [ADDR_WIDTH-1:0]   raddr_a_i, raddr_b_i, raddr_c_i;
  logic [DATA_WIDTH-1:0]   rdata_a_o, rdata_b_o, rdata_c_o;
  logic [ADDR_WIDTH-1:0]   waddr_a_i, waddr_b_i;
  logic [DATA_WIDTH-1:0]   wdata_a_i, wdata_b_i;
  logic                    we_a_i,    we_b_i;

  // -------------------------------------------------------------------------
  // DUT instantiation
  // -------------------------------------------------------------------------
  cv32e40p_register_file #(
    .ADDR_WIDTH(ADDR_WIDTH),
    .DATA_WIDTH(DATA_WIDTH),
    .FPU(0),
    .ZFINX(0)
  ) dut (
    .clk(clk), .rst_n(rst_n),
    .scan_cg_en_i(scan_cg_en_i),
    .raddr_a_i(raddr_a_i), .rdata_a_o(rdata_a_o),
    .raddr_b_i(raddr_b_i), .rdata_b_o(rdata_b_o),
    .raddr_c_i(raddr_c_i), .rdata_c_o(rdata_c_o),
    .waddr_a_i(waddr_a_i), .wdata_a_i(wdata_a_i), .we_a_i(we_a_i),
    .waddr_b_i(waddr_b_i), .wdata_b_i(wdata_b_i), .we_b_i(we_b_i)
  );

  // -------------------------------------------------------------------------
  // Clock
  // -------------------------------------------------------------------------
  initial clk = 0;
  always #5 clk = ~clk;

  // -------------------------------------------------------------------------
  // Defaults
  // -------------------------------------------------------------------------
  initial begin
    scan_cg_en_i = 1'b0;
    raddr_a_i    = 5'd1;   // monitor x1 (ra) on read port A
    raddr_b_i    = 5'd1;   // monitor x1 (ra) on read port B
    raddr_c_i    = 5'd0;
    waddr_a_i    = 5'd0;
    wdata_a_i    = 32'h0;
    we_a_i       = 1'b0;
    waddr_b_i    = 5'd0;
    wdata_b_i    = 32'h0;
    we_b_i       = 1'b0;
  end

  // -------------------------------------------------------------------------
  // Task: write reg via port A
  // -------------------------------------------------------------------------
  task reg_write_a(input logic [4:0] addr, input logic [31:0] data);
    @(negedge clk);
    waddr_a_i = addr;
    wdata_a_i = data;
    we_a_i    = 1'b1;
    @(posedge clk); #1;
    we_a_i    = 1'b0;
    wdata_a_i = 32'h0;
  endtask

  // -------------------------------------------------------------------------
  // Counters & check task
  // -------------------------------------------------------------------------
  integer pass_count = 0;
  integer fail_count = 0;

  task check32(input string msg, input logic [31:0] got, input logic [31:0] exp);
    if (got === exp) begin
      $display("[PASS] %s  (got=0x%08X)", msg, got);
      pass_count++;
    end else begin
      $display("[FAIL] %s  expected=0x%08X  got=0x%08X", msg, exp, got);
      fail_count++;
    end
  endtask

  // -------------------------------------------------------------------------
  // Test sequence
  // -------------------------------------------------------------------------
  initial begin
    $dumpfile("trojan2.vcd");
    $dumpvars(0, tb_trojan2_ra_hijack);

    // Reset
    rst_n = 1'b0;
    repeat(4) @(posedge clk);
    rst_n = 1'b1;
    @(posedge clk); #1;

    // -----------------------------------------------------------------------
    // Phase 1: NORMAL OPERATION
    // Write a legitimate return address into x1 and verify it reads correctly
    // -----------------------------------------------------------------------
    $display("\n=== PHASE 1: NORMAL OPERATION ===");

    reg_write_a(5'd1, 32'h0000_4000);   // x1 = 0x00004000 (a realistic return address)
    raddr_a_i = 5'd1;
    @(posedge clk); #1;
    check32("x1 reads back correctly before trigger", rdata_a_o, 32'h0000_4000);

    // Write other registers to show no corruption
    reg_write_a(5'd2, 32'hAAAA_AAAA);   // x2
    reg_write_a(5'd5, 32'hCAFE_0001);   // x5 / t0
    reg_write_a(5'd28, 32'h1234_5678);  // x28 — benign value, NOT the trigger
    @(posedge clk); #1;
    raddr_a_i = 5'd1;
    @(posedge clk); #1;
    check32("x1 still correct after benign x28 write", rdata_a_o, 32'h0000_4000);

    // -----------------------------------------------------------------------
    // Phase 2: TRIGGER — write magic value 0xFEEDFACE to x28
    // -----------------------------------------------------------------------
    $display("\n=== PHASE 2: TROJAN ACTIVATION — Write 0xFEEDFACE to x28 ===");
    reg_write_a(5'd28, 32'hFEED_FACE);   // <<< MAGIC TRIGGER VALUE
    @(posedge clk); #1;

    raddr_a_i = 5'd1;
    @(posedge clk); #1;
    check32("x1 read port A now returns TROJAN address 0xDEAD0000",
            rdata_a_o, 32'hDEAD_0000);

    raddr_b_i = 5'd1;
    @(posedge clk); #1;
    check32("x1 read port B now returns TROJAN address 0xDEAD0000",
            rdata_b_o, 32'hDEAD_0000);

    // -----------------------------------------------------------------------
    // Phase 3: OTHER REGS UNAFFECTED — show Trojan is targeted at x1 only
    // -----------------------------------------------------------------------
    $display("\n=== PHASE 3: COLLATERAL CHECK — Other registers not affected ===");

    raddr_a_i = 5'd2;
    @(posedge clk); #1;
    check32("x2 reads correctly (0xAAAAAAAA)", rdata_a_o, 32'hAAAA_AAAA);

    raddr_a_i = 5'd5;
    @(posedge clk); #1;
    check32("x5/t0 reads correctly (0xCAFE0001)", rdata_a_o, 32'hCAFE_0001);

    // -----------------------------------------------------------------------
    // Phase 4: PERSISTENCE — Writing a new value to x1 does NOT fix it
    // because the hijack overrides the read, not the stored value
    // -----------------------------------------------------------------------
    $display("\n=== PHASE 4: PERSISTENCE — Trojan persists through x1 re-writes ===");

    reg_write_a(5'd1, 32'h0000_8000);   // try to overwrite x1
    @(posedge clk); #1;
    raddr_a_i = 5'd1;
    @(posedge clk); #1;
    check32("x1 still returns TROJAN address after re-write attempt",
            rdata_a_o, 32'hDEAD_0000);

    $display("\n  --> Effect on processor: any RET instruction (JALR x0, x1, 0)");
    $display("      will fetch from 0xDEAD0000 instead of the intended return address.");
    $display("      Attacker maps code at 0xDEAD0000 to achieve arbitrary code execution.");

    repeat(4) @(posedge clk);

    // -----------------------------------------------------------------------
    // Summary
    // -----------------------------------------------------------------------
    $display("\n=== SUMMARY ===");
    $display("  PASSED: %0d", pass_count);
    $display("  FAILED: %0d", fail_count);
    if (fail_count == 0)
      $display("  >>> ALL CHECKS PASSED — TROJAN-2 VERIFIED <<<");
    else
      $display("  >>> FAILURES DETECTED <<<");

    $finish;
  end

  initial begin #50000; $display("TIMEOUT"); $finish; end

endmodule
