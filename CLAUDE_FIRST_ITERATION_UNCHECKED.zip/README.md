# IEEE HOST 2026 AHA! Challenge — Red Team Submission
## Target: openhwgroup cv32e40p RISC-V Processor

---

## 1. How AI Was Used to Generate This Submission

All RTL modifications and testbenches were generated using **Claude Sonnet 4.6** (Anthropic),
accessed via the **Claude.ai web UI** (claude.ai).

### Workflow

1. All 27 RTL source files for the cv32e40p were uploaded directly to the Claude.ai chat interface.
2. Claude autonomously read and analyzed the RTL to identify security-relevant modules:
   - `cv32e40p_cs_registers.sv` — interrupt enable control
   - `cv32e40p_register_file_ff.sv` — general-purpose registers
   - `cv32e40p_load_store_unit.sv` — memory write datapath
3. Surgical modifications were applied via Claude's `str_replace` tool, keeping diffs minimal for stealth.
4. Testbenches were generated to demonstrate both normal operation and Trojan activation.

### Models Used
- **Claude Sonnet 4.6** via claude.ai web chat interface
- All AI interaction logs are included in `ai_interaction_log.md`

---

## 2. Trojans Overview

| ID | Name | File Modified | Lines Changed | CVSS Score |
|----|------|--------------|---------------|------------|
| T1 | Interrupt Killswitch | `cv32e40p_cs_registers.sv` | +5 | **7.5 (High)** |
| T2 | Return Address Hijack | `cv32e40p_register_file_ff.sv` | +12 | **9.3 (Critical)** |
| T3 | Silent Store Corruption | `cv32e40p_load_store_unit.sv` | +3 | **8.2 (High)** |

---

## 3. Trojan 1 — Interrupt Killswitch

### File Modified
`cv32e40p_cs_registers.sv`

### Mechanism
A 1-bit persistent latch (`trojan_irq_lock_q`) is added to the CSR register file.
The latch is armed when the value `0xDEADC0DE` is written to the `mscratch` CSR (address `0x340`).

Once armed, the output signal `m_irq_enable_o` is permanently forced to `0`, regardless of
the value of `mstatus.MIE`. This disables all machine-mode interrupt delivery for the lifetime
of the processor session (until hard reset).

### Trigger
```
csrw mscratch, 0xDEADC0DE
```

### Payload
```
m_irq_enable_o = mstatus.MIE & ~trojan_irq_lock_q
```
All machine-mode interrupts (timer, external, software) are silently suppressed.

### Stealthiness
- Only **1 flip-flop** added to a module with hundreds
- `mscratch` is a legitimate scratch register; OS/firmware writes to it routinely
- The magic trigger value `0xDEADC0DE` is statistically improbable in normal use
- `m_irq_enable_o` already can be 0 during normal operation; the output change is not suspicious
- No change to any interface signal names or module ports

### CVSS 3.1 Score: **7.5 (High)**
```
CVSS:3.1/AV:L/AC:H/PR:H/UI:N/S:C/C:N/I:N/A:H
```
| Metric | Value | Rationale |
|--------|-------|-----------|
| Attack Vector | Local (L) | Requires ability to execute privileged instructions |
| Attack Complexity | High (H) | Must know exact trigger value |
| Privileges Required | High (H) | csrw mscratch is M-mode privileged |
| User Interaction | None (N) | No user action after trigger |
| Scope | Changed (C) | Affects interrupt subsystem beyond the CSR module |
| Confidentiality | None (N) | |
| Integrity | None (N) | |
| Availability | High (H) | All interrupt-driven operations permanently fail |

### Testbench
`tb_trojan1_irq_killswitch.sv`

---

## 4. Trojan 2 — Return Address Hijack

### File Modified
`cv32e40p_register_file_ff.sv`

### Mechanism
A 1-bit latch (`trojan_ra_poison_q`) monitors write port A and write port B. When the value
`0xFEEDFACE` is written to register `x28` (t3, a caller-saved temporary), the latch is set.

Once set, all **reads** of register `x1` (the return address register `ra`) from any read port
(rdata_a_o, rdata_b_o, rdata_c_o) are intercepted and return `0xDEAD0000` instead of the
actual stored value.

Because `ret` in RISC-V is `JALR x0, x1, 0`, this redirects all function returns to
`0xDEAD0000` — an address under attacker control.

### Trigger
```c
// In C: t3 = 0xFEEDFACE;
// In assembly:
li   t3, 0xFEEDFACE
```

### Payload
Any subsequent `ret` instruction jumps to `0xDEAD0000`.

### Stealthiness
- Override is at the **read port level**, not in the write path — x1's stored value is unmodified
- A debugger reading `x1` via the same read port will also see the poisoned value, making it
  appear that x1 genuinely contains `0xDEAD0000`
- Writing to `t3` (x28) is an extremely common compiler operation (register allocation spill)
- The trigger value `0xFEEDFACE` resembles a common debug/magic constant; it could be embedded
  in a data structure or constant pool without raising suspicion
- Adds only **1 FF + ~10 gates** to the register file

### CVSS 3.1 Score: **9.3 (Critical)**
```
CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:C/C:H/I:H/A:H
```
| Metric | Value | Rationale |
|--------|-------|-----------|
| Attack Vector | Local (L) | Attacker executes code on the processor |
| Attack Complexity | Low (L) | Only requires writing a known constant to t3 |
| Privileges Required | Low (L) | Unprivileged code can write t3 |
| User Interaction | None (N) | |
| Scope | Changed (C) | Escapes normal program control flow |
| Confidentiality | High (H) | Attacker-controlled code can read all memory |
| Integrity | High (H) | Arbitrary code execution |
| Availability | High (H) | Normal program flow permanently broken |

### Testbench
`tb_trojan2_ra_hijack.sv`

---

## 5. Trojan 3 — Silent Store Data Corruption

### File Modified
`cv32e40p_load_store_unit.sv`

### Mechanism
The `trans_wdata` signal, which carries the write data from the EX stage to the OBI bus,
is intercepted by a combinational override. When **both** of the following are true
simultaneously during a store:

1. `data_addr_int[7:0] == 8'hA5` (low byte of effective address equals 0xA5)
2. `data_wdata_ex_i[15:8] == 8'hBE` (byte 1 of store data equals 0xBE)

Then the **low byte** of `trans_wdata` is XOR'd with `0xFF`, silently flipping all 8 bits
before the data reaches the memory bus.

### Trigger
```c
// Any store to an address ending in 0xA5 whose data[15:8] == 0xBE
// Example:
*(volatile uint32_t *)(base + 0xA5) = 0xBEEF1234;
// What memory actually receives: 0xBEEF12CB
// (0x34 ^ 0xFF = 0xCB)
```

### Payload
Silent corruption of stored data. The processor, OS, and all software believe the correct
value was written. Only a logic analyzer on the memory bus would reveal the discrepancy.

### Stealthiness
- **Zero flip-flops added** — purely combinational, minimal PPA impact
- Trigger is a 2-condition coincidence on naturally occurring bus values — vanishingly rare
  in random traffic, yet easily engineered by an attacker who knows the trigger
- All bus control signals (`data_addr_o`, `data_we_o`, `data_be_o`) are unchanged —
  only the data payload is corrupted
- Corruption is byte-granular and XOR-based — looks like a random bit error, not an attack

### CVSS 3.1 Score: **8.2 (High)**
```
CVSS:3.1/AV:L/AC:H/PR:L/UI:N/S:C/C:N/I:H/A:L
```
| Metric | Value | Rationale |
|--------|-------|-----------|
| Attack Vector | Local (L) | Attacker controls what is stored and where |
| Attack Complexity | High (H) | Must control both address[7:0] and data[15:8] simultaneously |
| Privileges Required | Low (L) | Any store instruction — no privilege needed |
| User Interaction | None (N) | |
| Scope | Changed (C) | Corrupts system memory beyond the LSU |
| Confidentiality | None (N) | |
| Integrity | High (H) | Silent data corruption in memory — cryptographic keys, config, etc. |
| Availability | Low (L) | Eventual corruption may cause crashes |

### Testbench
`tb_trojan3_store_corruption.sv`

---

## 6. PPA Analysis

Run on each modified file using the provided `run_ppa.sh` script.
Results are located in the `metrics/` directory for each Trojan.

Expected PPA delta (vs. baseline):
- **T1**: +1 FF, +~5 gates → <0.01% area, negligible power, 0ps timing impact
- **T2**: +1 FF, +~15 gates on read mux → <0.02% area, <0.01% power, ~20ps on read path
- **T3**: +~8 gates on datapath → <0.01% area, negligible power, ~15ps on store path

---

## 7. File Manifest

```
submission/
├── README.md                          ← this file
├── ai_interaction_log.md              ← full Claude conversation transcript
│
├── trojan1_irq_killswitch/
│   ├── cv32e40p_cs_registers.sv       ← modified source
│   ├── tb_trojan1_irq_killswitch.sv   ← exploit testbench
│   └── metrics/                       ← PPA results from run_ppa.sh
│
├── trojan2_ra_hijack/
│   ├── cv32e40p_register_file_ff.sv   ← modified source
│   ├── tb_trojan2_ra_hijack.sv        ← exploit testbench
│   └── metrics/
│
└── trojan3_store_corruption/
    ├── cv32e40p_load_store_unit.sv    ← modified source
    ├── tb_trojan3_store_corruption.sv ← exploit testbench
    └── metrics/
```
