// =============================================================================
// Testbench: Trojan 1 - Interrupt Killswitch
// Target:    cv32e40p_cs_registers.sv
// Trigger:   Write 32'hDEADC0DE to CSR_MSCRATCH (addr 0x340)
// Payload:   m_irq_enable_o permanently forced to 0
// =============================================================================

`timescale 1ns/1ps

// Minimal package stub so the module compiles standalone
`define CSR_MSCRATCH 12'h340
`define CSR_MSTATUS  12'h300
`define CSR_MIE      12'h304
`define PRIV_LVL_M   2'b11
`define CSR_OP_WRITE 2'b01
`define CSR_OP_READ  2'b00

// Bring in the real package from your project; here we provide a self-contained
// simulation stub that re-declares needed types.
// If simulating with the full cv32e40p package, comment out this section.
package cv32e40p_pkg;
  typedef enum logic [11:0] {
    CSR_MSTATUS   = 12'h300,
    CSR_MIE       = 12'h304,
    CSR_MTVEC     = 12'h305,
    CSR_MSCRATCH  = 12'h340,
    CSR_MEPC      = 12'h341,
    CSR_MCAUSE    = 12'h342,
    CSR_MHARTID   = 12'hF14,
    CSR_MVENDORID = 12'hF11
  } csr_num_e;

  typedef enum logic [1:0] {
    CSR_OP_READ  = 2'b00,
    CSR_OP_WRITE = 2'b01,
    CSR_OP_SET   = 2'b10,
    CSR_OP_CLEAR = 2'b11
  } csr_opcode_e;

  typedef enum logic [1:0] {
    PRIV_LVL_U = 2'b00,
    PRIV_LVL_S = 2'b01,
    PRIV_LVL_H = 2'b10,
    PRIV_LVL_M = 2'b11
  } PrivLvl_t;

  typedef struct packed {
    logic uie;
    logic [1:0] padding0;
    logic mie;
    logic upie;
    logic [1:0] padding1;
    logic mpie;
    logic [1:0] padding2;
    PrivLvl_t mpp;
    logic [1:0] fs_dummy;
    logic [2:0] padding3;
    logic mprv;
    logic [13:0] padding4;
  } Status_t;

  typedef enum logic [1:0] {
    DBG_CAUSE_NONE = 2'b00
  } dbg_cause_e;

  typedef enum logic [1:0] {
    FS_OFF   = 2'b00,
    FS_DIRTY = 2'b11
  } FS_t;

  typedef struct packed {
    logic [3:0]  xdebugver;
    logic [11:0] padding;
    logic        ebreakm;
    logic        ebreaks;
    logic        ebreaku;
    logic        stepie;
    logic        stopcount;
    logic        stoptime;
    logic [2:0]  cause;
    logic        padding2;
    logic        mprven;
    logic        nmip;
    logic        step;
    PrivLvl_t    prv;
  } Dcsr_t;

  localparam XDEBUGVER_STD  = 4'h4;
  localparam DBG_CAUSE_NONE_V = 3'h0;

  localparam IRQ_MASK = 32'hFFFF0888;
  localparam C_FFLAG  = 5;
  localparam C_RM     = 3;
endpackage

module tb_trojan1_irq_killswitch;
  import cv32e40p_pkg::*;

  // -------------------------------------------------------------------------
  // DUT signals
  // -------------------------------------------------------------------------
  logic        clk, rst_n;
  csr_num_e    csr_addr_i;
  logic [31:0] csr_wdata_i;
  csr_opcode_e csr_op_i;
  logic [31:0] csr_rdata_o;
  logic        m_irq_enable_o;
  logic        u_irq_enable_o;
  logic [31:0] mie_bypass_o;
  logic [31:0] mip_i;
  logic        csr_irq_sec_i;
  logic        sec_lvl_o;
  logic [31:0] mepc_o, uepc_o;
  logic [31:0] mcounteren_o;
  logic [23:0] mtvec_o, utvec_o;
  logic [1:0]  mtvec_mode_o, utvec_mode_o;
  logic [31:0] hart_id_i;
  logic [31:0] mtvec_addr_i;
  logic        csr_mtvec_init_i;
  logic        fs_off_o;
  logic [2:0]  frm_o;
  logic [4:0]  fflags_i;
  logic        fflags_we_i, fregs_we_i;
  logic        debug_mode_i;
  logic [2:0]  debug_cause_i;
  logic        debug_csr_save_i;
  logic [31:0] depc_o;
  logic        debug_single_step_o, debug_ebreakm_o, debug_ebreaku_o;
  logic        trigger_match_o;
  logic [15:0][31:0] pmp_addr_o;
  logic [15:0][7:0]  pmp_cfg_o;
  PrivLvl_t    priv_lvl_o;
  logic [31:0] pc_if_i, pc_id_i, pc_ex_i;
  logic        csr_save_if_i, csr_save_id_i, csr_save_ex_i;
  logic        csr_restore_mret_i, csr_restore_uret_i, csr_restore_dret_i;
  logic [5:0]  csr_cause_i;
  logic        csr_save_cause_i;
  logic [1:0][31:0] hwlp_start_i, hwlp_end_i, hwlp_cnt_i;
  logic        mhpmevent_minstret_i, mhpmevent_load_i, mhpmevent_store_i;
  logic        mhpmevent_jump_i, mhpmevent_branch_i, mhpmevent_branch_taken_i;
  logic        mhpmevent_compressed_i, mhpmevent_jr_stall_i, mhpmevent_imiss_i;
  logic        mhpmevent_ld_stall_i, mhpmevent_pipe_stall_i;
  logic        apu_typeconflict_i, apu_contention_i, apu_dep_i, apu_wb_i;

  // -------------------------------------------------------------------------
  // DUT instantiation
  // -------------------------------------------------------------------------
  cv32e40p_cs_registers #(
    .N_HWLP(2), .APU(0), .A_EXTENSION(0), .FPU(0), .ZFINX(0),
    .PULP_SECURE(0), .USE_PMP(0), .N_PMP_ENTRIES(16),
    .NUM_MHPMCOUNTERS(1), .COREV_PULP(0), .COREV_CLUSTER(0),
    .DEBUG_TRIGGER_EN(1)
  ) dut (
    .clk(clk), .rst_n(rst_n),
    .hart_id_i(hart_id_i),
    .mtvec_o(mtvec_o), .utvec_o(utvec_o),
    .mtvec_mode_o(mtvec_mode_o), .utvec_mode_o(utvec_mode_o),
    .mtvec_addr_i(mtvec_addr_i), .csr_mtvec_init_i(csr_mtvec_init_i),
    .csr_addr_i(csr_addr_i), .csr_wdata_i(csr_wdata_i),
    .csr_op_i(csr_op_i), .csr_rdata_o(csr_rdata_o),
    .fs_off_o(fs_off_o), .frm_o(frm_o),
    .fflags_i(fflags_i), .fflags_we_i(fflags_we_i), .fregs_we_i(fregs_we_i),
    .mie_bypass_o(mie_bypass_o), .mip_i(mip_i),
    .m_irq_enable_o(m_irq_enable_o), .u_irq_enable_o(u_irq_enable_o),
    .csr_irq_sec_i(csr_irq_sec_i), .sec_lvl_o(sec_lvl_o),
    .mepc_o(mepc_o), .uepc_o(uepc_o), .mcounteren_o(mcounteren_o),
    .debug_mode_i(debug_mode_i), .debug_cause_i(debug_cause_i),
    .debug_csr_save_i(debug_csr_save_i), .depc_o(depc_o),
    .debug_single_step_o(debug_single_step_o),
    .debug_ebreakm_o(debug_ebreakm_o), .debug_ebreaku_o(debug_ebreaku_o),
    .trigger_match_o(trigger_match_o),
    .pmp_addr_o(pmp_addr_o), .pmp_cfg_o(pmp_cfg_o),
    .priv_lvl_o(priv_lvl_o),
    .pc_if_i(pc_if_i), .pc_id_i(pc_id_i), .pc_ex_i(pc_ex_i),
    .csr_save_if_i(csr_save_if_i), .csr_save_id_i(csr_save_id_i),
    .csr_save_ex_i(csr_save_ex_i),
    .csr_restore_mret_i(csr_restore_mret_i),
    .csr_restore_uret_i(csr_restore_uret_i),
    .csr_restore_dret_i(csr_restore_dret_i),
    .csr_cause_i(csr_cause_i), .csr_save_cause_i(csr_save_cause_i),
    .hwlp_start_i(hwlp_start_i), .hwlp_end_i(hwlp_end_i),
    .hwlp_cnt_i(hwlp_cnt_i),
    .mhpmevent_minstret_i(mhpmevent_minstret_i),
    .mhpmevent_load_i(mhpmevent_load_i),
    .mhpmevent_store_i(mhpmevent_store_i),
    .mhpmevent_jump_i(mhpmevent_jump_i),
    .mhpmevent_branch_i(mhpmevent_branch_i),
    .mhpmevent_branch_taken_i(mhpmevent_branch_taken_i),
    .mhpmevent_compressed_i(mhpmevent_compressed_i),
    .mhpmevent_jr_stall_i(mhpmevent_jr_stall_i),
    .mhpmevent_imiss_i(mhpmevent_imiss_i),
    .mhpmevent_ld_stall_i(mhpmevent_ld_stall_i),
    .mhpmevent_pipe_stall_i(mhpmevent_pipe_stall_i),
    .apu_typeconflict_i(apu_typeconflict_i),
    .apu_contention_i(apu_contention_i),
    .apu_dep_i(apu_dep_i), .apu_wb_i(apu_wb_i)
  );

  // -------------------------------------------------------------------------
  // Clock generation
  // -------------------------------------------------------------------------
  initial clk = 0;
  always #5 clk = ~clk;

  // -------------------------------------------------------------------------
  // Tie-off unused inputs
  // -------------------------------------------------------------------------
  initial begin
    hart_id_i         = 32'h0;
    mtvec_addr_i      = 32'h0000_0100;
    csr_mtvec_init_i  = 1'b0;
    mip_i             = 32'h0;
    csr_irq_sec_i     = 1'b0;
    fflags_i          = 5'h0;
    fflags_we_i       = 1'b0;
    fregs_we_i        = 1'b0;
    debug_mode_i      = 1'b0;
    debug_cause_i     = 3'h0;
    debug_csr_save_i  = 1'b0;
    pc_if_i           = 32'h0;
    pc_id_i           = 32'h0;
    pc_ex_i           = 32'h0;
    csr_save_if_i     = 1'b0;
    csr_save_id_i     = 1'b0;
    csr_save_ex_i     = 1'b0;
    csr_restore_mret_i= 1'b0;
    csr_restore_uret_i= 1'b0;
    csr_restore_dret_i= 1'b0;
    csr_cause_i       = 6'h0;
    csr_save_cause_i  = 1'b0;
    hwlp_start_i      = '0;
    hwlp_end_i        = '0;
    hwlp_cnt_i        = '0;
    mhpmevent_minstret_i     = 1'b0;
    mhpmevent_load_i         = 1'b0;
    mhpmevent_store_i        = 1'b0;
    mhpmevent_jump_i         = 1'b0;
    mhpmevent_branch_i       = 1'b0;
    mhpmevent_branch_taken_i = 1'b0;
    mhpmevent_compressed_i   = 1'b0;
    mhpmevent_jr_stall_i     = 1'b0;
    mhpmevent_imiss_i        = 1'b0;
    mhpmevent_ld_stall_i     = 1'b0;
    mhpmevent_pipe_stall_i   = 1'b0;
    apu_typeconflict_i       = 1'b0;
    apu_contention_i         = 1'b0;
    apu_dep_i                = 1'b0;
    apu_wb_i                 = 1'b0;
    csr_addr_i  = CSR_MSCRATCH;
    csr_wdata_i = 32'h0;
    csr_op_i    = CSR_OP_READ;
  end

  // -------------------------------------------------------------------------
  // Task: write a CSR
  // -------------------------------------------------------------------------
  task csr_write(input csr_num_e addr, input logic [31:0] data);
    @(negedge clk);
    csr_addr_i  = addr;
    csr_wdata_i = data;
    csr_op_i    = CSR_OP_WRITE;
    @(posedge clk); #1;
    csr_op_i    = CSR_OP_READ;
    csr_wdata_i = 32'h0;
  endtask

  // -------------------------------------------------------------------------
  // Test sequence
  // -------------------------------------------------------------------------
  integer pass_count = 0;
  integer fail_count = 0;

  task check(input string msg, input logic got, input logic exp);
    if (got === exp) begin
      $display("[PASS] %s  (got=%0b)", msg, got);
      pass_count++;
    end else begin
      $display("[FAIL] %s  expected=%0b  got=%0b", msg, exp, got);
      fail_count++;
    end
  endtask

  initial begin
    $dumpfile("trojan1.vcd");
    $dumpvars(0, tb_trojan1_irq_killswitch);

    // -----------------------------------------------------------------------
    // Phase 1: RESET
    // -----------------------------------------------------------------------
    rst_n = 1'b0;
    repeat(4) @(posedge clk);
    rst_n = 1'b1;
    @(posedge clk); #1;

    $display("\n=== PHASE 1: NORMAL OPERATION (interrupts should be ENABLED) ===");

    // Enable machine-mode interrupts via mstatus.MIE (bit 3)
    csr_write(CSR_MSTATUS, 32'h0000_0008);  // MIE=1
    @(posedge clk); #1;
    check("m_irq_enable_o == 1 after mstatus.MIE=1", m_irq_enable_o, 1'b1);

    // Write a benign value to mscratch — should NOT trigger Trojan
    csr_write(CSR_MSCRATCH, 32'hDEAD_BEEF);  // near-trigger but not exact
    @(posedge clk); #1;
    check("m_irq_enable_o still 1 after benign mscratch write", m_irq_enable_o, 1'b1);

    csr_write(CSR_MSCRATCH, 32'h1234_5678);
    @(posedge clk); #1;
    check("m_irq_enable_o still 1 after 0x12345678 mscratch write", m_irq_enable_o, 1'b1);

    // -----------------------------------------------------------------------
    // Phase 2: ACTIVATE TROJAN
    // -----------------------------------------------------------------------
    $display("\n=== PHASE 2: TROJAN ACTIVATION — Write 0xDEADC0DE to MSCRATCH ===");
    csr_write(CSR_MSCRATCH, 32'hDEAD_C0DE);  // <<< MAGIC TRIGGER VALUE
    @(posedge clk); #1;

    check("m_irq_enable_o == 0 IMMEDIATELY after trigger", m_irq_enable_o, 1'b0);

    // -----------------------------------------------------------------------
    // Phase 3: PERSISTENCE — Trojan cannot be undone
    // -----------------------------------------------------------------------
    $display("\n=== PHASE 3: PERSISTENCE — Trojan survives all CSR writes ===");

    // Try to re-enable interrupts by writing mstatus
    csr_write(CSR_MSTATUS, 32'h0000_0008);
    @(posedge clk); #1;
    check("m_irq_enable_o stays 0 after mstatus.MIE re-write", m_irq_enable_o, 1'b0);

    // Try writing different mscratch values
    csr_write(CSR_MSCRATCH, 32'hFFFF_FFFF);
    @(posedge clk); #1;
    check("m_irq_enable_o stays 0 after 0xFFFFFFFF mscratch write", m_irq_enable_o, 1'b0);

    csr_write(CSR_MSCRATCH, 32'h0000_0000);
    @(posedge clk); #1;
    check("m_irq_enable_o stays 0 after 0x00000000 mscratch write", m_irq_enable_o, 1'b0);

    repeat(5) @(posedge clk);

    // -----------------------------------------------------------------------
    // Summary
    // -----------------------------------------------------------------------
    $display("\n=== SUMMARY ===");
    $display("  PASSED: %0d", pass_count);
    $display("  FAILED: %0d", fail_count);
    if (fail_count == 0)
      $display("  >>> ALL CHECKS PASSED — TROJAN-1 VERIFIED <<<");
    else
      $display("  >>> FAILURES DETECTED <<<");

    $finish;
  end

  // Timeout watchdog
  initial begin
    #50000;
    $display("TIMEOUT");
    $finish;
  end

endmodule
