// =============================================================================
// Testbench: Trojan 3 - Silent Store Data Corruption
// Target:    cv32e40p_load_store_unit.sv
// Trigger:   Store to address where addr[7:0]==0xA5 AND data[15:8]==0xBE
//            (e.g., store 0xBEEF_1234 to address 0x????_??A5)
// Payload:   Low byte of trans_wdata XOR'd with 0xFF
//            e.g., 0xBEEF_1234 becomes 0xBEEF_12CB silently
// =============================================================================

`timescale 1ns/1ps

// Minimal stub for cv32e40p_pkg types needed by the LSU
package cv32e40p_pkg;
  localparam LOAD  = 1'b0;
  localparam STORE = 1'b1;
endpackage

// ---------------------------------------------------------------------------
// Minimal OBI interface stub (replaces cv32e40p_obi_interface)
// so we can test the LSU without the full project hierarchy.
// ---------------------------------------------------------------------------
module cv32e40p_obi_interface #(
  parameter  TRANS_STABILITY_GUARANTEED = 0
)(
  input  logic        clk,
  input  logic        rst_n,
  // Transaction port
  input  logic        trans_valid_i,
  output logic        trans_ready_o,
  input  logic [31:0] trans_addr_i,
  input  logic        trans_we_i,
  input  logic [3:0]  trans_be_i,
  input  logic [31:0] trans_wdata_i,
  input  logic        trans_atop_i,
  // Response port
  output logic        resp_valid_o,
  input  logic        resp_ready_i,
  output logic [31:0] resp_rdata_o,
  output logic        resp_err_o,
  // OBI port
  output logic        obi_req_o,
  input  logic        obi_gnt_i,
  output logic [31:0] obi_addr_o,
  output logic        obi_we_o,
  output logic [3:0]  obi_be_o,
  output logic [31:0] obi_wdata_o,
  output logic        obi_atop_o,
  input  logic        obi_rvalid_i,
  input  logic [31:0] obi_rdata_i,
  input  logic        obi_err_i
);
  // Passthrough: immediately grant and capture wdata for inspection
  assign obi_req_o   = trans_valid_i;
  assign trans_ready_o = obi_gnt_i;
  assign obi_addr_o  = trans_addr_i;
  assign obi_we_o    = trans_we_i;
  assign obi_be_o    = trans_be_i;
  assign obi_wdata_o = trans_wdata_i;   // <<< This is what we inspect
  assign obi_atop_o  = trans_atop_i;
  assign resp_valid_o = obi_rvalid_i;
  assign resp_rdata_o = obi_rdata_i;
  assign resp_err_o   = obi_err_i;
endmodule

// ---------------------------------------------------------------------------
// Testbench
// ---------------------------------------------------------------------------
module tb_trojan3_store_corruption;
  import cv32e40p_pkg::*;

  // DUT signals
  logic        clk, rst_n;
  // Inputs from EX stage
  logic        data_we_ex_i;
  logic [1:0]  data_type_ex_i;
  logic [31:0] data_wdata_ex_i;
  logic [1:0]  data_reg_offset_ex_i;
  logic        data_sign_ext_ex_i;
  logic        data_req_ex_i;
  logic        data_misaligned_ex_i;
  logic        data_load_event_ex_i;
  logic [31:0] operand_a_ex_i;   // effective address source
  // OBI (memory) side
  logic        data_req_o;
  logic        data_gnt_i;
  logic        data_rvalid_i;
  logic        data_err_i;
  logic        data_err_pmp_i;
  logic [31:0] data_addr_o;
  logic        data_we_o;
  logic [3:0]  data_be_o;
  logic [31:0] data_wdata_o;   // <<< WHAT ACTUALLY GETS WRITTEN TO MEMORY
  logic [31:0] data_rdata_i;
  // Back to pipeline
  logic [31:0] data_rdata_ex_o;
  logic        data_misaligned_o;
  logic        lsu_ready_ex_o;
  logic        lsu_ready_wb_o;
  logic        load_err_o, store_err_o;
  logic        p_elw_start_o, p_elw_finish_o;

  // DUT
  cv32e40p_load_store_unit dut (
    .clk(clk), .rst_n(rst_n),
    .data_we_ex_i(data_we_ex_i),
    .data_type_ex_i(data_type_ex_i),
    .data_wdata_ex_i(data_wdata_ex_i),
    .data_reg_offset_ex_i(data_reg_offset_ex_i),
    .data_sign_ext_ex_i(data_sign_ext_ex_i),
    .data_req_ex_i(data_req_ex_i),
    .operand_a_ex_i(operand_a_ex_i),
    .data_misaligned_ex_i(data_misaligned_ex_i),
    .data_load_event_ex_i(data_load_event_ex_i),
    .data_req_o(data_req_o),
    .data_gnt_i(data_gnt_i),
    .data_rvalid_i(data_rvalid_i),
    .data_err_i(data_err_i),
    .data_err_pmp_i(data_err_pmp_i),
    .data_addr_o(data_addr_o),
    .data_we_o(data_we_o),
    .data_be_o(data_be_o),
    .data_wdata_o(data_wdata_o),
    .data_rdata_i(data_rdata_i),
    .data_rdata_ex_o(data_rdata_ex_o),
    .data_misaligned_o(data_misaligned_o),
    .lsu_ready_ex_o(lsu_ready_ex_o),
    .lsu_ready_wb_o(lsu_ready_wb_o),
    .load_err_o(load_err_o),
    .store_err_o(store_err_o),
    .p_elw_start_o(p_elw_start_o),
    .p_elw_finish_o(p_elw_finish_o)
  );

  // Clock
  initial clk = 0;
  always #5 clk = ~clk;

  // Defaults
  initial begin
    data_gnt_i           = 1'b1;   // memory always grants immediately
    data_rvalid_i        = 1'b0;
    data_err_i           = 1'b0;
    data_err_pmp_i       = 1'b0;
    data_rdata_i         = 32'h0;
    data_we_ex_i         = 1'b0;
    data_type_ex_i       = 2'b00;  // word
    data_wdata_ex_i      = 32'h0;
    data_reg_offset_ex_i = 2'h0;
    data_sign_ext_ex_i   = 1'b0;
    data_req_ex_i        = 1'b0;
    operand_a_ex_i       = 32'h0;
    data_misaligned_ex_i = 1'b0;
    data_load_event_ex_i = 1'b0;
  end

  // -------------------------------------------------------------------------
  // Task: issue one aligned word store, return what was written to bus
  // -------------------------------------------------------------------------
  task do_store(
    input  logic [31:0] addr,
    input  logic [31:0] data,
    output logic [31:0] bus_wdata
  );
    @(negedge clk);
    operand_a_ex_i  = addr;
    data_wdata_ex_i = data;
    data_we_ex_i    = 1'b1;
    data_type_ex_i  = 2'b00;   // SW (word)
    data_req_ex_i   = 1'b1;
    @(posedge clk); #1;
    bus_wdata       = data_wdata_o;  // capture bus write data
    data_req_ex_i   = 1'b0;
    data_we_ex_i    = 1'b0;
    @(posedge clk); #1;
  endtask

  // -------------------------------------------------------------------------
  // Check helpers
  // -------------------------------------------------------------------------
  integer pass_count = 0;
  integer fail_count = 0;

  task check32(input string msg, input logic [31:0] got, input logic [31:0] exp);
    if (got === exp) begin
      $display("[PASS] %s  (bus_wdata=0x%08X)", msg, got);
      pass_count++;
    end else begin
      $display("[FAIL] %s  expected=0x%08X  got=0x%08X", msg, exp, got);
      fail_count++;
    end
  endtask

  // -------------------------------------------------------------------------
  // Test
  // -------------------------------------------------------------------------
  logic [31:0] captured;

  initial begin
    $dumpfile("trojan3.vcd");
    $dumpvars(0, tb_trojan3_store_corruption);

    rst_n = 1'b0;
    repeat(4) @(posedge clk);
    rst_n = 1'b1;
    @(posedge clk); #1;

    // -----------------------------------------------------------------------
    // Phase 1: NORMAL STORES — no trigger condition
    // -----------------------------------------------------------------------
    $display("\n=== PHASE 1: NORMAL STORES (no trigger) ===");

    // Store to address 0x1000_0000 (addr[7:0] = 0x00 ≠ 0xA5) — no trigger
    do_store(32'h1000_0000, 32'hBEEF_1234, captured);
    check32("Store to 0x10000000: bus data unchanged",
            captured, 32'hBEEF_1234);

    // Store with correct addr byte but wrong data byte — no trigger
    do_store(32'h1000_00A5, 32'hDEAD_1234, captured);  // data[15:8]=0xAD≠0xBE
    check32("Store addr=0xA5 but data[15:8]!=0xBE: bus data unchanged",
            captured, 32'hDEAD_1234);

    // Store with correct data byte but wrong addr byte — no trigger
    do_store(32'h1000_0000, 32'hBEEF_5678, captured);  // addr[7:0]=0x00≠0xA5
    check32("Store data[15:8]=0xBE but addr[7:0]!=0xA5: bus data unchanged",
            captured, 32'hBEEF_5678);

    // -----------------------------------------------------------------------
    // Phase 2: TRIGGER — both conditions met simultaneously
    // -----------------------------------------------------------------------
    $display("\n=== PHASE 2: TROJAN ACTIVATION — addr[7:0]=0xA5 AND data[15:8]=0xBE ===");

    // Write 0xBEEF_1234 to address 0x2000_00A5
    // Expected corrupt bus data: 0xBEEF_12CB  (0x34 XOR 0xFF = 0xCB)
    do_store(32'h2000_00A5, 32'hBEEF_1234, captured);
    $display("  Intended store:  0xBEEF_1234 -> addr 0x200000A5");
    $display("  Actual bus data: 0x%08X", captured);
    check32("Store 0xBEEF_1234 to 0x200000A5: low byte flipped (0x34->0xCB)",
            captured, 32'hBEEF_12CB);

    // Another trigger case: 0xBE00_FFAA to addr 0xXXXX_XXA5
    // data[15:8]=0xBE, addr[7:0]=0xA5 → low byte 0xAA XOR 0xFF = 0x55
    do_store(32'h0000_10A5, 32'hBE00_FFAA, captured);
    $display("  Intended store:  0xBE00_FFAA -> addr 0x000010A5");
    $display("  Actual bus data: 0x%08X", captured);
    check32("Store 0xBE00_FFAA to 0x000010A5: low byte flipped (0xAA->0x55)",
            captured, 32'hBE00_FF55);

    // -----------------------------------------------------------------------
    // Phase 3: VERIFY STEALTH — address is unchanged, only wdata corrupted
    // -----------------------------------------------------------------------
    $display("\n=== PHASE 3: STEALTH CHECK ===");
    $display("  data_addr_o (address on bus) = 0x%08X (correct, not modified)", data_addr_o);
    $display("  data_we_o (write enable)     = %0b (correct, not modified)", data_we_o);
    $display("  data_be_o (byte enables)     = 0x%01X (correct, not modified)", data_be_o);
    $display("  --> Only data payload silently corrupted; all control signals intact.");

    // -----------------------------------------------------------------------
    // Summary
    // -----------------------------------------------------------------------
    $display("\n=== SUMMARY ===");
    $display("  PASSED: %0d", pass_count);
    $display("  FAILED: %0d", fail_count);
    if (fail_count == 0)
      $display("  >>> ALL CHECKS PASSED — TROJAN-3 VERIFIED <<<");
    else
      $display("  >>> FAILURES DETECTED <<<");

    $finish;
  end

  initial begin #50000; $display("TIMEOUT"); $finish; end

endmodule
