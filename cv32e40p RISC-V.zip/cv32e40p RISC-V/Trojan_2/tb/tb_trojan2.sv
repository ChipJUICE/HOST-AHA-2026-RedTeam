// =============================================================================
// Testbench: Trojan 2 - Return Address Hijack
// Target:    cv32e40p_register_file_ff.sv
// Trigger:   Write 32'hFEEDFACE to register x28 (t3)
// Payload:   All subsequent reads of x1 (ra) return 32'hDEAD0000
//            -> any RET (JALR x0, x1, 0) jumps to attacker-controlled address
//
// NOTE: ADDR_WIDTH must be 6 (matching the real cv32e40p core instantiation).
//   bit[5]   = 0 for integer regs, 1 for FP regs
//   bits[4:0] = register index (0..31)
//   NUM_WORDS = 2^(6-1) = 32, making we_a_dec[28] valid.
//
// Compile order:
//   1. cv32e40p_register_file_ff.sv  (MODIFIED)
//   2. this testbench
// Run: bash run_sim.sh
// =============================================================================

`timescale 1ns/1ps

module tb_trojan2_ra_hijack;

  localparam ADDR_WIDTH = 6;   // 32 integer regs (indices 0-31) + FP bit
  localparam DATA_WIDTH = 32;

  logic                    clk, rst_n, scan_cg_en_i;
  logic [ADDR_WIDTH-1:0]   raddr_a_i, raddr_b_i, raddr_c_i;
  logic [DATA_WIDTH-1:0]   rdata_a_o, rdata_b_o, rdata_c_o;
  logic [ADDR_WIDTH-1:0]   waddr_a_i, waddr_b_i;
  logic [DATA_WIDTH-1:0]   wdata_a_i, wdata_b_i;
  logic                    we_a_i, we_b_i;

  cv32e40p_register_file #(
      .ADDR_WIDTH(ADDR_WIDTH), .DATA_WIDTH(DATA_WIDTH), .FPU(0), .ZFINX(0)
  ) dut (
      .clk(clk), .rst_n(rst_n), .scan_cg_en_i(scan_cg_en_i),
      .raddr_a_i(raddr_a_i), .rdata_a_o(rdata_a_o),
      .raddr_b_i(raddr_b_i), .rdata_b_o(rdata_b_o),
      .raddr_c_i(raddr_c_i), .rdata_c_o(rdata_c_o),
      .waddr_a_i(waddr_a_i), .wdata_a_i(wdata_a_i), .we_a_i(we_a_i),
      .waddr_b_i(waddr_b_i), .wdata_b_i(wdata_b_i), .we_b_i(we_b_i)
  );

  initial clk = 0;
  always #5 clk = ~clk;

  initial begin
    $monitor("T=%0t  wA=we:%b a:%0d d:%h  rdA(a=%0d)=%h  poison=%b",
             $time, we_a_i, waddr_a_i, wdata_a_i,
             raddr_a_i, rdata_a_o, dut.trojan_ra_poison_q);
  end

  initial begin
    scan_cg_en_i = 0;
    {raddr_a_i, raddr_b_i, raddr_c_i} = '0;
    raddr_a_i = 6'd1;
    raddr_b_i = 6'd1;
    {waddr_a_i, wdata_a_i, we_a_i} = '0;
    {waddr_b_i, wdata_b_i, we_b_i} = '0;
  end

  task automatic reg_write_a(input logic [5:0] addr, input logic [31:0] data);
    @(negedge clk);
    waddr_a_i = addr; wdata_a_i = data; we_a_i = 1'b1;
    @(posedge clk); #1;
    we_a_i = 0; wdata_a_i = 0;
  endtask

  int pass_count = 0, fail_count = 0;

  task automatic check32(input string msg, input logic [31:0] got, input logic [31:0] exp);
    if (got === exp) begin
      $display("  [PASS] T=%0t  %s  (0x%08X)", $time, msg, got); pass_count++;
    end else begin
      $display("  [FAIL] T=%0t  %s  exp=0x%08X got=0x%08X", $time, msg, exp, got); fail_count++;
    end
  endtask

  task automatic banner(input string t);
    $display("\n============================================================");
    $display("  %s", t);
    $display("============================================================");
  endtask

  initial begin
    $dumpfile("trojan2.vcd");
    $dumpvars(0, tb_trojan2_ra_hijack);

    rst_n = 0; repeat(4) @(posedge clk); rst_n = 1; @(posedge clk); #1;

    banner("PHASE 1: NORMAL OPERATION (pre-trigger baseline)");
    reg_write_a(6'd1, 32'h0000_4000);   // x1 = legitimate return address
    raddr_a_i = 6'd1; @(posedge clk); #1;
    check32("x1 reads back correctly BEFORE trigger", rdata_a_o, 32'h0000_4000);

    reg_write_a(6'd2,  32'hAAAA_AAAA);
    reg_write_a(6'd5,  32'hCAFE_0001);
    reg_write_a(6'd28, 32'h1234_5678);  // benign x28 -- NOT the trigger
    raddr_a_i = 6'd1; @(posedge clk); #1;
    check32("x1 still correct after benign x28 write", rdata_a_o, 32'h0000_4000);

    banner("PHASE 2: TROJAN TRIGGER -- x28 := 0xFEEDFACE");
    reg_write_a(6'd28, 32'hFEED_FACE);  // <<< MAGIC
    @(posedge clk); #1;

    raddr_a_i = 6'd1; @(posedge clk); #1;
    check32("x1 port A now returns TROJAN 0xDEAD0000", rdata_a_o, 32'hDEAD_0000);

    raddr_b_i = 6'd1; @(posedge clk); #1;
    check32("x1 port B now returns TROJAN 0xDEAD0000", rdata_b_o, 32'hDEAD_0000);

    banner("PHASE 3: COLLATERAL CHECK -- other registers intact");
    raddr_a_i = 6'd2; @(posedge clk); #1;
    check32("x2 still 0xAAAAAAAA", rdata_a_o, 32'hAAAA_AAAA);

    raddr_a_i = 6'd5; @(posedge clk); #1;
    check32("x5/t0 still 0xCAFE0001", rdata_a_o, 32'hCAFE_0001);

    banner("PHASE 4: PERSISTENCE -- x1 overwrite cannot restore");
    reg_write_a(6'd1, 32'h0000_8000);
    raddr_a_i = 6'd1; @(posedge clk); #1;
    check32("x1 STILL returns 0xDEAD0000 after overwrite attempt", rdata_a_o, 32'hDEAD_0000);

    $display("\n  [INFO] Effect: every RET (JALR x0,x1,0) jumps to 0xDEAD0000");
    repeat(4) @(posedge clk);

    banner("SUMMARY");
    $display("  PASSED: %0d", pass_count);
    $display("  FAILED: %0d", fail_count);
    if (fail_count == 0) $display("  >>> TROJAN-2 VERIFIED <<<");
    else                 $display("  >>> FAILURES DETECTED <<<");
    $finish;
  end

  initial begin #50000; $display("TIMEOUT"); $finish; end
endmodule
