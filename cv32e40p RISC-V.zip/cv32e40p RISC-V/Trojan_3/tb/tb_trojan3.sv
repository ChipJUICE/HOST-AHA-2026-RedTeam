// =============================================================================
// Testbench: Trojan 3 - Silent Store Data Corruption
// Target:    cv32e40p_load_store_unit.sv
// Trigger:   Store with  addr[7:0] == 0xA0  AND  data[15:8] == 0xBE  simultaneously
//            - 0xA0  = 10100000  -> addr[1:0]==00 (word-aligned)
//            - 0xBE  is compared against BYTE 1 of the store data
//              (so e.g. 0xDEAD_BEEF has byte1 = 0xBE -> triggers)
// Payload:   byte 0 of trans_wdata is XOR'd with 0xFF before reaching the bus
//
// Byte numbering reminder for a 32-bit word WWXX_YYZZ:
//   byte 3 (bits 31:24) = WW
//   byte 2 (bits 23:16) = XX
//   byte 1 (bits 15:8)  = YY   <-- trigger compares this
//   byte 0 (bits  7:0)  = ZZ   <-- this byte is flipped
//
// Compile order:
//   1. cv32e40p_obi_interface.sv   (unmodified, from openhwgroup/cv32e40p)
//   2. cv32e40p_load_store_unit.sv (MODIFIED)
//   3. this testbench
// Run: bash run_sim.sh
// =============================================================================

`timescale 1ns/1ps

module tb_trojan3_store_corruption;

  logic        clk, rst_n;
  logic        data_we_ex_i;
  logic [ 1:0] data_type_ex_i;
  logic [31:0] data_wdata_ex_i;
  logic [ 1:0] data_reg_offset_ex_i;
  logic [ 1:0] data_sign_ext_ex_i;
  logic        data_req_ex_i;
  logic [31:0] operand_a_ex_i;
  logic [31:0] operand_b_ex_i;
  logic        addr_useincr_ex_i;
  logic        data_misaligned_ex_i;
  logic        data_load_event_ex_i;
  logic [ 5:0] data_atop_ex_i;

  logic        data_req_o;
  logic        data_gnt_i;
  logic        data_rvalid_i;
  logic        data_err_i;
  logic        data_err_pmp_i;
  logic [31:0] data_addr_o;
  logic        data_we_o;
  logic [ 3:0] data_be_o;
  logic [31:0] data_wdata_o;
  logic [31:0] data_rdata_i;
  logic [ 5:0] data_atop_o;

  logic [31:0] data_rdata_ex_o;
  logic        data_misaligned_o;
  logic        lsu_ready_ex_o;
  logic        lsu_ready_wb_o;
  logic        busy_o;
  logic        p_elw_start_o, p_elw_finish_o;

  cv32e40p_load_store_unit dut (
      .clk                 (clk),
      .rst_n               (rst_n),
      .data_req_o          (data_req_o),
      .data_gnt_i          (data_gnt_i),
      .data_rvalid_i       (data_rvalid_i),
      .data_err_i          (data_err_i),
      .data_err_pmp_i      (data_err_pmp_i),
      .data_addr_o         (data_addr_o),
      .data_we_o           (data_we_o),
      .data_be_o           (data_be_o),
      .data_wdata_o        (data_wdata_o),
      .data_rdata_i        (data_rdata_i),
      .data_we_ex_i        (data_we_ex_i),
      .data_type_ex_i      (data_type_ex_i),
      .data_wdata_ex_i     (data_wdata_ex_i),
      .data_reg_offset_ex_i(data_reg_offset_ex_i),
      .data_load_event_ex_i(data_load_event_ex_i),
      .data_sign_ext_ex_i  (data_sign_ext_ex_i),
      .data_rdata_ex_o     (data_rdata_ex_o),
      .data_req_ex_i       (data_req_ex_i),
      .operand_a_ex_i      (operand_a_ex_i),
      .operand_b_ex_i      (operand_b_ex_i),
      .addr_useincr_ex_i   (addr_useincr_ex_i),
      .data_misaligned_ex_i(data_misaligned_ex_i),
      .data_misaligned_o   (data_misaligned_o),
      .data_atop_ex_i      (data_atop_ex_i),
      .data_atop_o         (data_atop_o),
      .p_elw_start_o       (p_elw_start_o),
      .p_elw_finish_o      (p_elw_finish_o),
      .lsu_ready_ex_o      (lsu_ready_ex_o),
      .lsu_ready_wb_o      (lsu_ready_wb_o),
      .busy_o              (busy_o)
  );

  initial clk = 0;
  always #5 clk = ~clk;

  initial begin
    $monitor("T=%0t  req=%b we=%b addr=%h in_data=%h  |  bus_wdata=%h",
             $time, data_req_o, data_we_o, data_addr_o,
             data_wdata_ex_i, data_wdata_o);
  end

  initial begin
    data_gnt_i           = 1'b1;
    data_rvalid_i        = 1'b0;
    data_err_i           = 1'b0;
    data_err_pmp_i       = 1'b0;
    data_rdata_i         = 32'h0;
    data_we_ex_i         = 1'b0;
    data_type_ex_i       = 2'b00;
    data_wdata_ex_i      = 32'h0;
    data_reg_offset_ex_i = 2'h0;
    data_sign_ext_ex_i   = 2'h0;
    data_req_ex_i        = 1'b0;
    operand_a_ex_i       = 32'h0;
    operand_b_ex_i       = 32'h0;
    addr_useincr_ex_i    = 1'b0;
    data_misaligned_ex_i = 1'b0;
    data_load_event_ex_i = 1'b0;
    data_atop_ex_i       = 6'h0;
  end

  // Issue a word-aligned store and capture what appears on the bus
  task automatic do_store(
      input  logic [31:0] addr,
      input  logic [31:0] data,
      output logic [31:0] bus_wdata
  );
    @(negedge clk);
    operand_a_ex_i  = addr;
    data_wdata_ex_i = data;
    data_we_ex_i    = 1'b1;
    data_type_ex_i  = 2'b00;   // SW (word)
    data_req_ex_i   = 1'b1;
    @(posedge clk); #1;
    bus_wdata     = data_wdata_o;
    data_req_ex_i = 1'b0;
    data_we_ex_i  = 1'b0;
    @(posedge clk); #1;
  endtask

  int pass_count = 0, fail_count = 0;

  task automatic check32(input string msg, input logic [31:0] got, input logic [31:0] exp);
    if (got === exp) begin
      $display("  [PASS] T=%0t  %s  (bus=0x%08X)", $time, msg, got); pass_count++;
    end else begin
      $display("  [FAIL] T=%0t  %s  exp=0x%08X got=0x%08X", $time, msg, exp, got); fail_count++;
    end
  endtask

  task automatic banner(input string t);
    $display("\n============================================================");
    $display("  %s", t);
    $display("============================================================");
  endtask

  logic [31:0] captured;

  initial begin
    $dumpfile("trojan3.vcd");
    $dumpvars(0, tb_trojan3_store_corruption);

    rst_n = 0; repeat(4) @(posedge clk); rst_n = 1; @(posedge clk); #1;

    // -----------------------------------------------------------------------
    // PHASE 1: NORMAL - stores that violate at least one trigger condition
    // -----------------------------------------------------------------------
    banner("PHASE 1: NORMAL STORES (pre-trigger baseline)");

    // Neither condition met: addr[7:0]=0x00, byte1=0x12
    do_store(32'h1000_0000, 32'hDEAD_1234, captured);
    check32("addr=0x10000000 data=0xDEAD1234 (byte1=0x12) -> unchanged",
            captured, 32'hDEAD_1234);

    // Address condition met, data condition NOT met: byte1=0x12 (not 0xBE)
    do_store(32'h1000_00A0, 32'hDEAD_1234, captured);
    check32("addr[7:0]=0xA0 but byte1=0x12 (!=0xBE) -> unchanged",
            captured, 32'hDEAD_1234);

    // Data condition met, address condition NOT met: addr[7:0]=0x00
    do_store(32'h1000_0000, 32'hDEAD_BEEF, captured);
    check32("byte1=0xBE but addr[7:0]=0x00 (!=0xA0) -> unchanged",
            captured, 32'hDEAD_BEEF);

    // -----------------------------------------------------------------------
    // PHASE 2: TRIGGER - both conditions met
    // -----------------------------------------------------------------------
    banner("PHASE 2: TROJAN TRIGGER -- addr[7:0]==0xA0 AND byte1==0xBE");

    // 0xDEAD_BEEF to 0x200000A0: byte1=0xBE, byte0=0xEF -> 0xEF^0xFF=0x10
    $display("  Intended: 0xDEAD_BEEF -> 0x200000A0");
    do_store(32'h2000_00A0, 32'hDEAD_BEEF, captured);
    check32("Low byte flipped: 0xDEADBEEF -> 0xDEADBE10 (0xEF^0xFF=0x10)",
            captured, 32'hDEAD_BE10);

    // 0xCAFE_BE42 to 0x000010A0: byte1=0xBE, byte0=0x42 -> 0x42^0xFF=0xBD
    $display("  Intended: 0xCAFE_BE42 -> 0x000010A0");
    do_store(32'h0000_10A0, 32'hCAFE_BE42, captured);
    check32("Low byte flipped: 0xCAFEBE42 -> 0xCAFEBEBD (0x42^0xFF=0xBD)",
            captured, 32'hCAFE_BEBD);

    // -----------------------------------------------------------------------
    // PHASE 3: STEALTH -- control signals on bus are unmodified
    // -----------------------------------------------------------------------
    banner("PHASE 3: STEALTH CHECK -- control signals unmodified");
    // Issue a triggered store and inspect bus while request is live
    @(negedge clk);
    operand_a_ex_i  = 32'h2000_00A0;
    data_wdata_ex_i = 32'hDEAD_BEEF;
    data_we_ex_i    = 1'b1;
    data_type_ex_i  = 2'b00;
    data_req_ex_i   = 1'b1;
    @(posedge clk); #1;
    $display("  Processor-intended payload    : 0x%08X", data_wdata_ex_i);
    $display("  data_addr_o (bus)             : 0x%08X  (NOT modified)", data_addr_o);
    $display("  data_we_o (bus)               : %0b          (NOT modified)", data_we_o);
    $display("  data_be_o (bus)               : 0x%01X         (NOT modified)", data_be_o);
    $display("  data_wdata_o (bus)            : 0x%08X  (CORRUPTED)", data_wdata_o);
    $display("  [INFO] Processor believes it stored 0xDEADBEEF.");
    $display("         Memory actually received   0xDEADBE10.");
    $display("         Invisible without bus-level logic analysis.");
    data_req_ex_i = 0; data_we_ex_i = 0;
    @(posedge clk); #1;

    repeat(4) @(posedge clk);

    banner("SUMMARY");
    $display("  PASSED: %0d", pass_count);
    $display("  FAILED: %0d", fail_count);
    if (fail_count == 0) $display("  >>> TROJAN-3 VERIFIED <<<");
    else                 $display("  >>> FAILURES DETECTED <<<");
    $finish;
  end

  initial begin #50000; $display("TIMEOUT"); $finish; end
endmodule
