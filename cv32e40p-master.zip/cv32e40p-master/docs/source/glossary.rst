..
   Copyright 2024 OpenHW Group and Dolphin Design
   SPDX-License-Identifier: Apache-2.0 WITH SHL-2.1
  
   Licensed under the Solderpad Hardware License v 2.1 (the "License");
   you may not use this file except in compliance with the License, or,
   at your option, the Apache License version 2.0.
   You may obtain a copy of the License at
  
   https://solderpad.org/licenses/SHL-2.1/
  
   Unless required by applicable law or agreed to in writing, any work
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

.. _glossary:

Glossary
========

* **ALU**: Arithmetic/Logic Unit
* **ASIC**: Application-Specific Integrated Circuit
* **Byte**: 8-bit data item
* **CPU**: Central Processing Unit, processor
* **CSR**: Control and Status Register
* **Custom extension**: Non-Standard extension to the RISC-V base instruction set (RISC-V Instruction Set Manual, Volume I: User-Level ISA)
* **EX**: Instruction Execute
* **FPGA**: Field Programmable Gate Array
* **FPU**: Floating Point Unit
* **Halfword**: 16-bit data item
* **Halfword aligned address**: An address is halfword aligned if it is divisible by 2
* **ID**: Instruction Decode
* **IF**: Instruction Fetch (:ref:`instruction-fetch`)
* **ISA**: Instruction Set Architecture
* **KGE**: kilo gate equivalents (NAND2)
* **LSU**: Load Store Unit (:ref:`load-store-unit`)
* **M-Mode**: Machine Mode (RISC-V Instruction Set Manual, Volume II: Privileged Architecture)
* **OBI**: Open Bus Interface
* **PC**: Program Counter
* **PULP platform**: Parallel Ultra Low Power Platform (<https://pulp-platform.org>)
* **RV32C**: RISC-V Compressed (C extension)
* **RV32F**: RISC-V Floating Point (F extension)
* **SIMD**: Single Instruction/Multiple Data
* **Standard extension**: Standard extension to the RISC-V base instruction set (RISC-V Instruction Set Manual, Volume I: User-Level ISA)
* **WARL**: Write Any Values, Reads Legal Values
* **WB**: Write Back of instruction results
* **WLRL**: Write/Read Only Legal Values
* **Word**: 32-bit data item
* **Word aligned address**: An address is word aligned if it is divisible by 4
* **WPRI**: Reserved Writes Preserve Values, Reads Ignore Values
